create function get_all_children_node(targetId int)
  returns varchar(1000)
  BEGIN
    declare resultNode varchar(2000);     --     返回的结果字符串
    declare parentNode varchar(1000);     --     每次查询的父节点
    declare firstNode int;
    declare level varchar(1000);
    set resultNode = -1;
    set parentNode = targetId;
    set firstNode = 1;

    while parentNode is not null do         --  当父节点不为空时执行
    if firstNode=1 then
        set firstNode = 2;
    elseif  firstNode  >  1  then
        set resultNode = concat(resultNode, ",",parentNode);
        select group_concat(area_no)into parentNode from base_area where find_in_set(parent_area_no, parentNode) > 0;
    end if;
    end while;
    return resultNode;
END;

