create function updateHarborResult(STAKE_NO varchar(40), CHARGE_PORT varchar(40))
  returns decimal(19, 2)
  begin
    declare c decimal(19,2);
    declare p decimal(19,2);
    declare cp decimal(19,2);

    select t1.ct/t2.ct into c from
                                  (select substring_index(ct, '/', 1) as ct from base_shore_charger where stakeNo  = STAKE_NO and chargerNo = CHARGE_PORT) t1,
                                  (select substring_index(ct, '/', -1) as ct from base_shore_charger where stakeNo = STAKE_NO and chargerNo = CHARGE_PORT) t2;

    select t1.pt/t2.pt into  p from
                                   (select substring_index(pt, '/', 1)  as pt from base_shore_charger where stakeNo  = STAKE_NO and chargerNo = CHARGE_PORT) t1,
                                   (select substring_index(pt, '/', -1) as pt from base_shore_charger where stakeNo  = STAKE_NO and chargerNo = CHARGE_PORT) t2;

    set cp = c*p;
    if cp is null 
        then set cp = 1;
    end if ;

    return cp;
end;

